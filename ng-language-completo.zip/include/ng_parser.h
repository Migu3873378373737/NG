#ifndef NG_PARSER_H
#define NG_PARSER_H

#include "ng_lexer.h"
#include "ng_ast.h"

typedef struct {
    NGLexer* lexer;
    NGToken current;
    NGToken previous;
    bool has_error;
    const char* filename;
} NGParser;

void ng_parser_init(NGParser* parser, NGLexer* lexer, const char* filename);
NGAstNode* ng_parser_parse_program(NGParser* parser);

#endif // NG_PARSER_H
