# NG (Next Generation) Language

Linguagem de programação independente, com identidade sintática própria, interpretador nativo, AST modular e CLI construído em **C puro (padrão ISO C11)**.

---

## 1. Estrutura do Projeto

```
oi/
├── Makefile                # Build automatizado para Linux/Android/Windows
├── include/                # Cabeçalhos da arquitetura C11
│   ├── ng.h
│   ├── ng_lexer.h          # Análise léxica e tokens próprios
│   ├── ng_parser.h         # Análise sintática com blocos [...]
│   ├── ng_ast.h            # Árvore Sintática Abstrata (AST)
│   ├── ng_value.h          # Sistema unificado de tipos e valores
│   ├── ng_runtime.h        # Tabelas de símbolos e escopos
│   ├── ng_interpreter.h    # Avaliador e runtime nativo
│   ├── ng_error.h          # Códigos de erro NG-XXX
│   ├── ng_module.h         # Resolução em NG-modulos/
│   └── ng_n3cache.h        # Cache N3 e integridade
├── src/                    # Implementações em C11
│   ├── main.c              # CLI "ng"
│   ├── lexer.c
│   ├── parser.c
│   ├── ast.c
│   ├── value.c
│   ├── runtime.c
│   └── interpreter.c
├── NG-modulos/             # Módulos centrais da linguagem
└── testes/                 # Bateria de programas .ng
    ├── 01_ola_mundo.ng
    ├── 02_variaveis.ng
    ├── 03_g_y.ng
    ├── 04_condicoes.ng
    └── 05_funcoes.ng
```

---

## 2. Como Compilar no Termux / Linux

Para compilar o binário `ng`:

```bash
make
```

Ou diretamente com o compilador C:

```bash
clang -Wall -Wextra -std=c11 -O2 -Iinclude src/*.c -o bin/ng
```

---

## 3. Comandos do CLI

```bash
# Exibir versão e ajuda
./bin/ng versao
./bin/ng ajuda

# Verificar sintaxe sem executar
./bin/ng verificar testes/01_ola_mundo.ng

# Executar programas NG
./bin/ng executar testes/01_ola_mundo.ng
./bin/ng executar testes/03_g_y.ng
./bin/ng executar testes/04_condicoes.ng
./bin/ng executar testes/05_funcoes.ng

# Executar bateria de testes completa
make test
```
