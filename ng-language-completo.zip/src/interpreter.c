#include "ng_interpreter.h"
#include "ng_error.h"
#include "ng_lexer.h"
#include "ng_module.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void ng_interp_init(NGInterpreter* interp, const char* filename, bool is_subinterpreter) {
    interp->globals = ng_env_new(NULL);
    interp->current_env = interp->globals;
    interp->reg_y = ng_val_null();
    interp->current_file = filename;
    interp->is_subinterpreter = is_subinterpreter;
    interp->receiver_table = NULL;
}

void ng_interp_cleanup(NGInterpreter* interp) {
    if (interp->globals) {
        ng_env_free(interp->globals);
        interp->globals = NULL;
    }
    ng_val_free(&interp->reg_y);
}

static NGValue eval_expression(NGInterpreter* interp, NGAstNode* node);

NGValue ng_interp_call_func(NGInterpreter* interp, const NGValue* func, NGValue* args, size_t arg_count) {
    if (!interp || !func) return ng_val_null();

    if (func->type == NG_VAL_NATIVE_FUNC) {
        if (func->as.native_func.fn) {
            return func->as.native_func.fn(interp, args, arg_count);
        }
        return ng_val_null();
    }

    if (func->type == NG_VAL_FUNCTION) {
        NGEnv* local_env = ng_env_new(interp->globals);
        for (size_t i = 0; i < arg_count && i < func->as.func.param_count; i++) {
            ng_env_set(local_env, func->as.func.params[i], ng_val_clone(&args[i]));
        }
        NGEnv* prev_env = interp->current_env;
        interp->current_env = local_env;
        NGValue ret = ng_val_null();
        if (func->as.func.body) {
            ng_interp_run(interp, func->as.func.body);
            ret = ng_val_clone(&interp->reg_y);
        }
        interp->current_env = prev_env;
        ng_env_free(local_env);
        return ret;
    }

    return ng_val_null();
}

static bool execute_statement(NGInterpreter* interp, NGAstNode* node) {
    if (!node) return true;

    switch (node->type) {
        case NG_AST_STMT_PRINT: {
            NGValue v = eval_expression(interp, node->as.print_stmt.expr);
            ng_val_print(&v);
            ng_val_free(&v);
            return true;
        }

        case NG_AST_STMT_Y: {
            ng_val_free(&interp->reg_y);
            interp->reg_y = eval_expression(interp, node->as.y_stmt.expr);
            return true;
        }

        case NG_AST_STMT_G: {
            if (node->as.g_stmt.expr != NULL) {
                NGValue v = eval_expression(interp, node->as.g_stmt.expr);
                ng_val_print(&v);
                ng_val_free(&v);
            } else {
                ng_val_print(&interp->reg_y);
            }
            return true;
        }

        case NG_AST_STMT_ASSIGN: {
            NGValue v = eval_expression(interp, node->as.assign_stmt.value);
            ng_env_set(interp->current_env, node->as.assign_stmt.name, v);
            return true;
        }

        case NG_AST_STMT_TABLE_SET: {
            /* Resolve the table object first */
            NGValue tbl_val;
            bool tbl_found = false;
            if (node->as.table_set.table &&
                node->as.table_set.table->type == NG_AST_EXPR_IDENTIFIER) {
                tbl_found = ng_env_get(interp->current_env,
                                       node->as.table_set.table->as.id_expr.name,
                                       &tbl_val);
            } else {
                tbl_val = eval_expression(interp, node->as.table_set.table);
                tbl_found = true;
            }
            if (!tbl_found || tbl_val.type != NG_VAL_TABLE || !tbl_val.as.table) {
                return true;
            }
            NGValue field_val = eval_expression(interp, node->as.table_set.value);
            ng_table_set(tbl_val.as.table, node->as.table_set.field, field_val);
            return true;
        }

        case NG_AST_STMT_IF: {
            NGValue cond = eval_expression(interp, node->as.if_stmt.condition);
            bool is_true = false;
            if (cond.type == NG_VAL_BOOL) is_true = cond.as.boolean;
            else if (cond.type == NG_VAL_NUMBER) is_true = (cond.as.number != 0.0);
            else if (cond.type == NG_VAL_STRING && cond.as.string) is_true = (strlen(cond.as.string) > 0);
            ng_val_free(&cond);

            if (is_true) {
                if (node->as.if_stmt.then_block) {
                    return ng_interp_run(interp, node->as.if_stmt.then_block);
                }
            } else if (node->as.if_stmt.else_block) {
                return ng_interp_run(interp, node->as.if_stmt.else_block);
            }
            return true;
        }

        case NG_AST_STMT_WHILE: {
            while (true) {
                NGValue cond = eval_expression(interp, node->as.while_stmt.condition);
                bool is_true = false;
                if (cond.type == NG_VAL_BOOL) is_true = cond.as.boolean;
                else if (cond.type == NG_VAL_NUMBER) is_true = (cond.as.number != 0.0);
                ng_val_free(&cond);
                
                if (!is_true) break;

                if (!ng_interp_run(interp, node->as.while_stmt.block)) {
                    return false;
                }
            }
            return true;
        }

        case NG_AST_STMT_FUNC: {
            NGValue f;
            f.type = NG_VAL_FUNCTION;
            f.as.func.name = strdup(node->as.func_stmt.name);
            f.as.func.param_count = node->as.func_stmt.param_count;
            if (f.as.func.param_count > 0) {
                f.as.func.params = (char**)malloc(sizeof(char*) * f.as.func.param_count);
                for (size_t i = 0; i < f.as.func.param_count; i++) {
                    f.as.func.params[i] = strdup(node->as.func_stmt.params[i]);
                }
            } else {
                f.as.func.params = NULL;
            }
            f.as.func.body = node->as.func_stmt.body;
            ng_env_set(interp->globals, node->as.func_stmt.name, f);
            return true;
        }

        case NG_AST_STMT_IMPORT: {
            return ng_module_load_into_env(node->as.import_stmt.module_name, interp);
        }

        case NG_AST_PROGRAM: {
            for (size_t i = 0; i < node->as.program.count; i++) {
                if (!execute_statement(interp, node->as.program.statements[i])) {
                    return false;
                }
            }
            return true;
        }

        default:
            eval_expression(interp, node);
            return true;
    }
}

static NGValue eval_expression(NGInterpreter* interp, NGAstNode* node) {
    if (!node) return ng_val_null();

    switch (node->type) {
        case NG_AST_EXPR_LITERAL:
            return ng_val_clone(&node->as.literal_expr.value);

        case NG_AST_EXPR_IDENTIFIER: {
            if (strcmp(node->as.id_expr.name, "Y") == 0) {
                return ng_val_clone(&interp->reg_y);
            }
            NGValue out;
            if (ng_env_get(interp->current_env, node->as.id_expr.name, &out)) {
                return ng_val_clone(&out);
            }
            ng_error_print(NG_ERR_UNDEFINED_VAR, "Variavel Nao Definida", interp->current_file, node->line, node->column,
                           "A variavel referenciada nao foi declarada anteriormente.", "Certifique-se de atribuir um valor antes do uso.");
            return ng_val_null();
        }

        case NG_AST_EXPR_BINARY: {
            NGValue l = eval_expression(interp, node->as.binary_expr.left);
            NGValue r = eval_expression(interp, node->as.binary_expr.right);
            NGValue res = ng_val_null();

            if (l.type == NG_VAL_NUMBER && r.type == NG_VAL_NUMBER) {
                switch (node->as.binary_expr.op) {
                    case NG_TOK_PLUS:     res = ng_val_number(l.as.number + r.as.number); break;
                    case NG_TOK_MINUS:    res = ng_val_number(l.as.number - r.as.number); break;
                    case NG_TOK_STAR:     res = ng_val_number(l.as.number * r.as.number); break;
                    case NG_TOK_SLASH:    res = ng_val_number(r.as.number != 0 ? l.as.number / r.as.number : 0); break;
                    case NG_TOK_EQ:       res = ng_val_bool(l.as.number == r.as.number); break;
                    case NG_TOK_NEQ:      res = ng_val_bool(l.as.number != r.as.number); break;
                    case NG_TOK_LT:       res = ng_val_bool(l.as.number < r.as.number); break;
                    case NG_TOK_LTE:      res = ng_val_bool(l.as.number <= r.as.number); break;
                    case NG_TOK_GT:       res = ng_val_bool(l.as.number > r.as.number); break;
                    case NG_TOK_GTE:      res = ng_val_bool(l.as.number >= r.as.number); break;
                    default: break;
                }
            } else if (l.type == NG_VAL_STRING && r.type == NG_VAL_STRING && node->as.binary_expr.op == NG_TOK_PLUS) {
                size_t len = strlen(l.as.string) + strlen(r.as.string);
                char* concat = (char*)malloc(len + 1);
                strcpy(concat, l.as.string);
                strcat(concat, r.as.string);
                res = ng_val_string(concat);
                free(concat);
            } else if (node->as.binary_expr.op == NG_TOK_EQ) {
                /* Compare mixed types: null == null, bool == bool, string == string */
                if (l.type == NG_VAL_NULL && r.type == NG_VAL_NULL) {
                    res = ng_val_bool(true);
                } else if (l.type == NG_VAL_BOOL && r.type == NG_VAL_BOOL) {
                    res = ng_val_bool(l.as.boolean == r.as.boolean);
                } else if (l.type == NG_VAL_STRING && r.type == NG_VAL_STRING) {
                    res = ng_val_bool(strcmp(l.as.string, r.as.string) == 0);
                } else {
                    res = ng_val_bool(false);
                }
            } else if (node->as.binary_expr.op == NG_TOK_NEQ) {
                if (l.type == NG_VAL_NULL && r.type == NG_VAL_NULL) {
                    res = ng_val_bool(false);
                } else if (l.type == NG_VAL_BOOL && r.type == NG_VAL_BOOL) {
                    res = ng_val_bool(l.as.boolean != r.as.boolean);
                } else if (l.type == NG_VAL_STRING && r.type == NG_VAL_STRING) {
                    res = ng_val_bool(strcmp(l.as.string, r.as.string) != 0);
                } else {
                    res = ng_val_bool(true);
                }
            }
            ng_val_free(&l);
            ng_val_free(&r);
            return res;
        }

        case NG_AST_EXPR_TABLE_GET: {
            NGValue tbl = eval_expression(interp, node->as.table_get.table);
            if (tbl.type != NG_VAL_TABLE || !tbl.as.table) {
                return ng_val_null();
            }
            NGValue field_val;
            if (ng_table_get(tbl.as.table, node->as.table_get.field, &field_val)) {
                return ng_val_clone(&field_val);
            }
            return ng_val_null();
        }

        case NG_AST_EXPR_CALL: {
            NGTable* prev_receiver = interp->receiver_table;
            if (node->as.call_expr.callee && node->as.call_expr.callee->type == NG_AST_EXPR_TABLE_GET) {
                NGValue rec_val = eval_expression(interp, node->as.call_expr.callee->as.table_get.table);
                if (rec_val.type == NG_VAL_TABLE) {
                    interp->receiver_table = rec_val.as.table;
                }
            }

            NGValue callee = eval_expression(interp, node->as.call_expr.callee);

            /* Se o callee for uma tabela com __call ou novo, chama o metodo correspondente */
            if (callee.type == NG_VAL_TABLE && callee.as.table) {
                NGValue call_method;
                if (ng_table_get(callee.as.table, "__call", &call_method) ||
                    ng_table_get(callee.as.table, "novo", &call_method) ||
                    ng_table_get(callee.as.table, "Novo", &call_method)) {
                    interp->receiver_table = callee.as.table;
                    size_t arg_count = node->as.call_expr.arg_count;
                    NGValue* args = NULL;
                    if (arg_count > 0) {
                        args = (NGValue*)malloc(sizeof(NGValue) * arg_count);
                        for (size_t i = 0; i < arg_count; i++) {
                            args[i] = eval_expression(interp, node->as.call_expr.args[i]);
                        }
                    }
                    NGValue result = ng_interp_call_func(interp, &call_method, args, arg_count);
                    for (size_t i = 0; i < arg_count; i++) {
                        ng_val_free(&args[i]);
                    }
                    free(args);
                    ng_val_free(&callee);
                    interp->receiver_table = prev_receiver;
                    return result;
                }
            }

            if (callee.type == NG_VAL_NATIVE_FUNC) {
                /* Evaluate arguments */
                size_t arg_count = node->as.call_expr.arg_count;
                NGValue* args = NULL;
                if (arg_count > 0) {
                    args = (NGValue*)malloc(sizeof(NGValue) * arg_count);
                    for (size_t i = 0; i < arg_count; i++) {
                        args[i] = eval_expression(interp, node->as.call_expr.args[i]);
                    }
                }
                NGValue result = ng_val_null();
                if (callee.as.native_func.fn) {
                    result = callee.as.native_func.fn(interp, args, arg_count);
                }
                for (size_t i = 0; i < arg_count; i++) {
                    ng_val_free(&args[i]);
                }
                free(args);
                ng_val_free(&callee);
                interp->receiver_table = prev_receiver;
                return result;
            }

            if (callee.type != NG_VAL_FUNCTION) {
                ng_error_print(NG_ERR_UNDEFINED_FUNC, "Funcao Nao Encontrada", interp->current_file, node->line, node->column,
                               "Tentativa de chamar um identificador que nao e uma funcao valida.", "Verifique o nome da funcao.");
                ng_val_free(&callee);
                interp->receiver_table = prev_receiver;
                return ng_val_null();
            }
            NGEnv* local_env = ng_env_new(interp->globals);
            for (size_t i = 0; i < node->as.call_expr.arg_count && i < callee.as.func.param_count; i++) {
                NGValue arg_val = eval_expression(interp, node->as.call_expr.args[i]);
                ng_env_set(local_env, callee.as.func.params[i], arg_val);
            }
            NGEnv* prev_env = interp->current_env;
            interp->current_env = local_env;
            NGValue ret = ng_val_null();
            if (callee.as.func.body) {
                ng_interp_run(interp, callee.as.func.body);
                /* Return value via Y register */
                ret = ng_val_clone(&interp->reg_y);
            }
            interp->current_env = prev_env;
            ng_env_free(local_env);
            ng_val_free(&callee);
            interp->receiver_table = prev_receiver;
            return ret;
        }

        case NG_AST_EXPR_FUNC: {
            NGValue f;
            f.type = NG_VAL_FUNCTION;
            f.as.func.name = node->as.func_expr.name ? strdup(node->as.func_expr.name) : strdup("<anonima>");
            f.as.func.param_count = node->as.func_expr.param_count;
            if (f.as.func.param_count > 0) {
                f.as.func.params = (char**)malloc(sizeof(char*) * f.as.func.param_count);
                for (size_t i = 0; i < f.as.func.param_count; i++) {
                    f.as.func.params[i] = strdup(node->as.func_expr.params[i]);
                }
            } else {
                f.as.func.params = NULL;
            }
            f.as.func.body = node->as.func_expr.body;
            return f;
        }

        default:
            return ng_val_null();
    }
}

bool ng_interp_run(NGInterpreter* interp, NGAstNode* program) {
    if (!program) return false;
    return execute_statement(interp, program);
}
